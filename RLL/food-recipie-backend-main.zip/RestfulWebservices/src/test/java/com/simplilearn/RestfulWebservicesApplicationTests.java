package com.simplilearn;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.simplilearn.entity.Admin;
import com.simplilearn.entity.User;
import com.simplilearn.repo.AdminRepository;
import com.simplilearn.repo.UserRepository;
import com.simplilearn.service.AdminService;
import com.simplilearn.service.UserService;

@SpringBootTest (classes = RestfulWebservicesApplication .class)
class RestfulWebservicesApplicationTests 
{
	@Autowired
	private AdminRepository adminRepo;
	
	@Autowired
	private UserRepository userRepo;

	@Test
// @Disabled
	
	
	public void testAdmin()
{
		Admin A=new Admin();
	    A.setId(3);
		A.setUsername("ramani");
	    A.setPassword("1234");
	    adminRepo.save(A);
	}
@Test
public void testUser()
{
	User u=new User();
	u.setId(8);
	u.setName("ramani");
	u.setEmail("ramani@gmail.com");
	u.setPassword("123");
	u.setPhone(123456789);
	userRepo.save(u);
	
	}

}
