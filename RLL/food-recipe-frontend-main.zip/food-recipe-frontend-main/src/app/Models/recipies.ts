export class Recipe {
    id : BigInteger;
    name: string;
    category: string;
    ingrediants: string;
    cookingSteps: string;
    imgurl: string;
}